# Installation

## Python package

```bash
pip install gpu-timing
```

The core package has no mandatory third-party runtime dependencies.

## CUDA

GPU timing with `backend="cuda"` requires a compatible NVIDIA CUDA runtime that provides the CUDA Runtime API (`cudart`). `gpu-timing` does not bundle the CUDA toolkit or redistribute NVIDIA binaries.

An explicit runtime library path can be supplied with:

```bash
export GPU_TIMING_CUDA_LIBRARY=/path/to/libcudart.so
```

## HIP / ROCm

GPU timing with `backend="hip"` requires a compatible HIP runtime (`libamdhip64`). `gpu-timing` does not bundle ROCm/HIP binaries.

```bash
export GPU_TIMING_HIP_LIBRARY=/path/to/libamdhip64.so
```
