# Compatibility

## Python

The package declares Python 3.10 or newer.

## CUDA

CUDA timing requires an external CUDA Runtime API (`cudart`) library. The first implementation uses dynamic loading rather than a Python CUDA package dependency.

## HIP / ROCm

HIP timing requires an external HIP runtime (`amdhip64` / `libamdhip64`).

## Validation status

The source has been validated in a CPU-only environment for importability, unit tests, package wheel creation, and CLI smoke tests. CUDA and HIP runtime execution require appropriate GPU hardware and vendor runtimes; those runtime tests have not been falsely marked as passed here.
