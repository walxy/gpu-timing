# References

The timing model is based on vendor and benchmarking documentation rather than claims invented by the library.

- NVIDIA CUDA C Best Practices Guide: https://docs.nvidia.com/cuda/cuda-c-best-practices-guide/
- NVIDIA CUDA Runtime API — Events: https://docs.nvidia.com/cuda/cuda-runtime-api/group__CUDART__EVENT.html
- NVIDIA CUDA C Programming Guide: https://docs.nvidia.com/cuda/cuda-c-programming-guide/
- AMD HIP documentation: https://rocm.docs.amd.com/projects/HIP/en/latest/
- PyTorch benchmark utilities: https://docs.pytorch.org/docs/stable/benchmark_utils.html
- Python timing functions: https://docs.python.org/3/library/time.html
- Python pyperf: https://pyperf.readthedocs.io/
- Google Benchmark: https://github.com/google/benchmark
