# Quickstart

## Host timing

```python
from gpu_timing import Timer

with Timer(mode="host") as timer:
    do_work()

print(timer.elapsed_ms)
```

## GPU timing

```python
from gpu_timing import Timer

with Timer(mode="gpu", backend="cuda") as timer:
    launch_gpu_work()

print(timer.elapsed_ms)
```

The callable itself must enqueue the work onto the stream being timed. A native stream handle can be supplied with `stream=`.

## Benchmarking

```python
from gpu_timing import benchmark

result = benchmark(
    launch_gpu_work,
    backend="cuda",
    warmup=10,
    iterations=50,
)

print(result)
```

The benchmark reports a median as its primary headline statistic and includes mean, min, max, standard deviation, and coefficient of variation.
