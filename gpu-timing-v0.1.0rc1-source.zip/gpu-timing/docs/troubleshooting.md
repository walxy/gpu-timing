# Troubleshooting

## CUDA backend unavailable

Verify that a compatible CUDA runtime is installed and visible to the process. Set `GPU_TIMING_CUDA_LIBRARY` to an explicit `libcudart` path when dynamic discovery is insufficient.

## HIP backend unavailable

Verify that ROCm/HIP is installed and visible. Set `GPU_TIMING_HIP_LIBRARY` to an explicit `libamdhip64` path if required.

## Measurements are noisy

Increase the sample count, use appropriate warm-up, avoid concurrent background workloads, and inspect the reported CV. For highly variable workloads, use a profiler to determine the source of variability rather than assuming the timer is at fault.
