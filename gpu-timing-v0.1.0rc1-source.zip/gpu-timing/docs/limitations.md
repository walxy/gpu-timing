# Limitations

The first release deliberately avoids claims beyond the primitive it measures.

- GPU event timing is not a complete per-kernel profiler.
- Concurrent streams can influence an event interval.
- GPU clock, thermal, power, scheduling, and initialization state can change results.
- Timing resolution is backend-defined; representing a value in nanoseconds does not imply nanosecond physical accuracy.
- Automatic calibration, CUPTI, Nsight integration, clock locking, cache control, and distributed benchmarking are not in v0.1.
