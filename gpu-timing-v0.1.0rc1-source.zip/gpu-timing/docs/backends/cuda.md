# CUDA backend

The CUDA backend dynamically loads the CUDA Runtime API and uses CUDA events for timing. It requires an external NVIDIA CUDA runtime and does not bundle NVIDIA software.
