# HIP backend

The HIP backend dynamically loads the HIP runtime and uses HIP events for timing. It requires an external ROCm/HIP installation and does not bundle ROCm software.
