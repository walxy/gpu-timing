# FAQ

## Why not `time.time()`?

Wall-clock time is not the right abstraction for precise elapsed-performance measurements. `perf_counter_ns()` is used for host timing.

## Why did a host timer report almost zero for a GPU call?

The GPU operation may have been queued asynchronously. Use GPU event timing when the research question is device-event elapsed time.

## Does GPU event time equal kernel execution time?

Not necessarily. Event elapsed time measures the interval between recorded event markers in the relevant execution stream, and concurrent work can affect the interval.

## Why is the first iteration slower?

Initialization and lazy-loading effects are common causes. Warm-up is enabled by default for benchmarks.

## Can this replace Nsight?

No. `gpu-timing` answers a lightweight timing question. Nsight and CUPTI provide deeper profiling and tracing capabilities.
