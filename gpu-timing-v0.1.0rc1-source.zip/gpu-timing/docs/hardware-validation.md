# Hardware validation

`gpu-timing` deliberately stops short of claiming complete GPU support until the native CUDA and HIP paths have been exercised on real hardware.

## NVIDIA CUDA

Validate at minimum:

- backend discovery and device count
- default/null stream timing
- explicit native stream timing
- explicit device selection
- asynchronous workload timing
- multiple sequential samples
- first-use versus warmed-up behavior
- device-context change detection
- event cleanup after success and failure
- short-workload measurement overhead

CUDA documents that events capture a stream's execution state and that the event and stream must belong to the same CUDA context. It also documents that event elapsed time can be influenced by other stream work.

## AMD ROCm / HIP

Validate the equivalent cases for HIP. HIP documents that events recorded in a non-null stream reach their recorded state after preceding commands in that stream complete.

## Interpretation

A passing hardware test demonstrates that the tested runtime/hardware combination behaves correctly. It does not establish universal support for every CUDA, driver, ROCm, GPU, operating-system, or virtualization combination.

See the project-level `VALIDATION.md` for the release gate.
