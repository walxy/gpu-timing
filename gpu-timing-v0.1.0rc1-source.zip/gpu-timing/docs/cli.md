# CLI

The initial CLI provides version and runtime-dependency information.

```bash
gpu-timing version
gpu-timing info
```

Workload execution from shell commands is intentionally deferred until a safe, portable interface can be specified without introducing framework-specific assumptions.
