# Development

Install development dependencies:

```bash
python -m pip install -e '.[dev]'
```

Run tests:

```bash
pytest
```

Run linting:

```bash
ruff check .
ruff format --check .
```

The engineering priority is correctness first, followed by API stability, measurement quality, and low overhead.
