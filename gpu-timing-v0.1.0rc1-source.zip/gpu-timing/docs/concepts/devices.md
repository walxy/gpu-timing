# Devices

When `device=None`, the backend uses the runtime's current device. When an explicit device index is supplied, the backend selects that device before creating timing events.

Explicit device selection should therefore be treated as a deliberate runtime state change.
