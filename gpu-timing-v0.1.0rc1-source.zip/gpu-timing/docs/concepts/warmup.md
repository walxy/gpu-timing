# Warm-up

Warm-up calls are executed but not recorded as benchmark samples. Warm-up is intended to reduce first-use effects such as module initialization and other one-time setup.

There is no universal correct warm-up count. Use a value appropriate to the workload and report the chosen setting with the benchmark result.
