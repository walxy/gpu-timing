# Host vs device timing

A GPU API call frequently enqueues work and returns before the GPU finishes. A host timer around that call can therefore under-report device work.

Use `mode="gpu"` when the intended measurement is GPU event elapsed time. Use `mode="host"` for CPU-side work or orchestration, and `mode="sync_host"` when the explicit synchronization is part of the latency being measured.
