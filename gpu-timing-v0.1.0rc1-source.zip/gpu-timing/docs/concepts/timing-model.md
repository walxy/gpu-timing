# Timing model

There are three distinct measurements:

| Mode | Primary clock | Typical question |
|---|---|---|
| `host` | CPU performance counter | How long did the host code take? |
| `gpu` | CUDA/HIP event timeline | How much device-event elapsed time occurred between two event markers? |
| `sync_host` | CPU counter + device synchronization | How long did this operation take from the host perspective including completion? |

Do not interpret these values as interchangeable.
