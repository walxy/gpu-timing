# Measurement overhead

Every measurement mechanism has overhead. For very short workloads, event recording, synchronization, Python dispatch, and result handling can become a material fraction of the measured interval.

The v0.1 implementation establishes correct event timing first. Batched execution and automatic calibration are intentionally deferred to a later release.
