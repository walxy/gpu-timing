# Synchronization

GPU event timing requires the end event to reach completion before its elapsed timestamp is consumed. `gpu-timing` synchronizes the end event rather than inserting a full device synchronization for ordinary GPU timing.

A full device synchronization is still available conceptually through `sync_host`, but synchronization can perturb concurrency and should not be inserted casually into every benchmark iteration.
