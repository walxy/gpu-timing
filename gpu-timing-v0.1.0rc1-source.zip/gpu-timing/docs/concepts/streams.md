# Streams

CUDA and HIP event timing follows stream ordering. A measurement interval can be affected by other work in the same or interacting execution timelines.

`stream=None` uses the backend runtime's default/null stream semantics. Advanced callers may pass a native stream handle as an integer or `ctypes.c_void_p`.

The library does not currently translate framework-specific stream objects from PyTorch, CuPy, JAX, or other frameworks.
