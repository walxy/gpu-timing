# Result API

`BenchmarkResult` is an immutable structured result with:

- backend and device information
- timing mode
- warm-up and sample counts
- min/max/mean/median/stddev/CV
- quality status and warnings
- environment metadata
- optional raw sample storage

Use `to_dict()` or `to_json()` for machine-readable output.
