# Benchmark API

```python
from gpu_timing import benchmark
```

The function accepts a zero-argument callable and returns `BenchmarkResult` after warm-up and repeated measurement.
