# Timer API

```python
from gpu_timing import Timer, GPUTimer
```

`Timer` supports `host`, `gpu`, and `sync_host` modes.

`GPUTimer` is an alias for `Timer` retained as a more explicit name for GPU-facing code.
