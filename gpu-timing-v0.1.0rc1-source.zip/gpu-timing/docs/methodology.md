# Benchmark methodology

A defensible GPU benchmark needs more than a stopwatch.

## 1. Warm up

Initialization, lazy loading, memory allocation, and other one-time effects can contaminate cold measurements. CUDA documentation specifically notes that lazy loading can move module initialization into measured execution. Warm-up calls are therefore excluded from the reported samples.

## 2. Measure repeated samples

A single measurement is fragile. `gpu-timing` repeats the operation and reports distribution statistics.

## 3. Prefer median

The median is the primary headline because occasional system or runtime outliers can pull the mean away from the common case.

## 4. Inspect variation

The coefficient of variation (CV) is reported as a compact variability indicator. The current quality warning uses a 5% heuristic threshold; this is a reporting heuristic, not a universal scientific cutoff.

## 5. Keep allocation outside the timed region

Allocate tensors, buffers, models, and other resources before the benchmark when the research question is kernel/workload execution rather than allocation cost.

## 6. Understand synchronization

GPU work may continue after the CPU call returns. GPU mode records an end event and waits for that event before reading the elapsed duration. `sync_host` intentionally measures host elapsed time through an explicit device synchronization and is therefore an end-to-end diagnostic mode rather than a replacement for GPU event timing.
