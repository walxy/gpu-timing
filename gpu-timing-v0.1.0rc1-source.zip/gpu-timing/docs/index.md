# gpu-timing

`gpu-timing` is a lightweight Python library for correct, repeatable GPU timing with native CUDA/HIP events.

The central design rule is simple: **GPU timing and CPU timing are different measurements.**

## What it provides

- Native CUDA event timing through the CUDA Runtime API.
- Native HIP event timing through the HIP runtime API.
- Host timing with Python's high-resolution performance counter.
- Warm-up and repeated benchmark execution.
- Mean, median, min, max, standard deviation, and coefficient of variation.
- Structured results and JSON serialization.
- Explicit timing semantics and benchmark-quality warnings.

## What it does not try to be

`gpu-timing` is not a profiler and does not replace Nsight Systems, Nsight Compute, or CUPTI. Those tools answer deeper tracing and kernel-analysis questions.
