# Security Policy

Please report suspected security issues privately to the repository maintainer rather than opening a public issue with exploit details.

`gpu-timing` executes native GPU runtime calls through dynamically loaded vendor libraries. Keep CUDA/ROCm runtimes and system drivers patched according to the vendor's security guidance.
