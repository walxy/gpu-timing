# gpu-timing Validation Status

This repository is a release candidate and explicitly separates software validation from real accelerator hardware validation.

## Current release candidate

- Version: **0.1.0rc1**
- Software validation maturity: **B0 — CPU/static/package validated**
- Final v0.1.0 release gate: **real CUDA and HIP hardware validation required**

## Passed in the current CPU-only environment

- Python source compilation
- Unit tests: **13 passed**
- Package importability
- CLI version/info smoke tests
- Host timing and benchmark behavior
- Result/statistics serialization logic
- Exception-preservation and cleanup behavior
- Wheel build
- Isolated wheel installation/import
- Clean source-archive integrity

## Pending on real hardware

| Area | NVIDIA CUDA | AMD ROCm/HIP | Status |
|---|---:|---:|---|
| Runtime discovery | Required | Required | Pending hardware |
| One-shot GPU timing | Required | Required | Pending hardware |
| Repeated benchmark | Required | Required | Pending hardware |
| Default/null stream | Required | Required | Pending hardware |
| Explicit stream | Required | Required | Pending hardware |
| Device selection | Required | Required | Pending hardware |
| Device-switch protection | Required | Required | Pending hardware |
| Async workload correctness | Required | Required | Pending hardware |
| Event cleanup | Required | Required | Pending hardware |
| Short-workload overhead | Required | Required | Pending hardware |
| Cross-version runtime loading | Required | Required | Pending hardware |

## What hardware validation must establish

1. Native CUDA event timing works on representative NVIDIA systems.
2. Native HIP event timing works on representative AMD systems.
3. Device and stream semantics match the documented API contract.
4. Asynchronous workloads are not accidentally measured as CPU enqueue time.
5. Exception and cleanup paths remain correct under real backend failures.
6. Measurement overhead is characterized for short workloads.
7. Runtime-library discovery works on the validated operating systems.

## Release gate

`v0.1.0` should not be described as fully hardware-validated until representative CUDA and HIP runtime matrices have been executed and documented.
