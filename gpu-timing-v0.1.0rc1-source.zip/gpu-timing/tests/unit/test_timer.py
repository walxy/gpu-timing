import time

import pytest

from gpu_timing import Timer
from gpu_timing.errors import ConfigurationError, TimingError


def test_host_timer() -> None:
    with Timer(mode="host") as timer:
        time.sleep(0.001)
    assert timer.elapsed_ns > 0
    assert timer.elapsed_ms > 0


def test_invalid_mode() -> None:
    with pytest.raises(ConfigurationError):
        Timer(mode="invalid")


def test_timer_requires_start_before_stop() -> None:
    timer = Timer(mode="host")
    with pytest.raises(TimingError):
        timer.stop()
