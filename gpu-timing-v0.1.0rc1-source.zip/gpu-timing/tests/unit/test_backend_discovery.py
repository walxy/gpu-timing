import pytest

from gpu_timing.backend import load_backend
from gpu_timing.errors import ConfigurationError


def test_invalid_backend_name() -> None:
    with pytest.raises(ConfigurationError):
        load_backend("vulkan")


def test_backend_modules_import_without_hardware() -> None:
    from gpu_timing.backends.cuda import CudaBackend
    from gpu_timing.backends.hip import HipBackend

    assert CudaBackend.__name__ == "CudaBackend"
    assert HipBackend.__name__ == "HipBackend"
