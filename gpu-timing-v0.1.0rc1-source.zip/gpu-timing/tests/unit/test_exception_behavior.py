import pytest

from gpu_timing import Timer, benchmark


def test_timer_context_does_not_mask_workload_exception() -> None:
    with pytest.raises(RuntimeError, match="work failed"):
        with Timer(mode="host"):
            raise RuntimeError("work failed")


def test_benchmark_validates_iterations_and_warmup() -> None:
    with pytest.raises(ValueError):
        benchmark(lambda: None, iterations=0, mode="host")
    with pytest.raises(ValueError):
        benchmark(lambda: None, warmup=-1, mode="host")


def test_benchmark_validates_configuration_before_warmup() -> None:
    calls = 0

    def workload() -> None:
        nonlocal calls
        calls += 1

    from gpu_timing.errors import ConfigurationError

    with pytest.raises(ConfigurationError):
        benchmark(workload, warmup=3, iterations=1, mode="invalid")
    assert calls == 0



def test_timer_cleanup_error_does_not_mask_workload_exception() -> None:
    timer = Timer(mode="host")

    def broken_close() -> None:
        raise RuntimeError("cleanup failed")

    timer.close = broken_close  # type: ignore[method-assign]
    with pytest.raises(RuntimeError, match="work failed"):
        with timer:
            raise RuntimeError("work failed")

