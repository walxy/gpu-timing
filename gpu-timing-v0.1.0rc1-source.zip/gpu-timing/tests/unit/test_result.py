from gpu_timing.result import BenchmarkResult


def test_result_json_and_format() -> None:
    result = BenchmarkResult(
        backend="host",
        device=None,
        mode="host",
        warmup=0,
        samples=3,
        min_ns=100,
        max_ns=300,
        mean_ns=200.0,
        median_ns=200.0,
        stddev_ns=100.0,
        cv=0.5,
        quality="warn",
        warnings=("test warning",),
        metadata={"test": True},
        sample_ns=(100, 200, 300),
    )
    payload = result.to_dict(include_samples=True)
    assert payload["sample_ns"] == [100, 200, 300]
    assert "quality:   WARN" in str(result)
    assert '"backend": "host"' in result.to_json()
