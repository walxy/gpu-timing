import time

from gpu_timing import benchmark


def test_host_benchmark() -> None:
    result = benchmark(lambda: time.sleep(0.001), warmup=1, iterations=5, mode="host")
    assert result.samples == 5
    assert result.median_ns > 0
    assert result.min_ns <= result.median_ns <= result.max_ns


def test_benchmark_normalizes_mode_in_result() -> None:
    result = benchmark(lambda: None, warmup=0, iterations=3, mode="HOST")
    assert result.mode == "host"
    assert result.backend == "host"


