from gpu_timing.statistics import summarize


def test_summarize_basic_statistics() -> None:
    result = summarize([100, 200, 300])
    assert result["count"] == 3
    assert result["min_ns"] == 100
    assert result["max_ns"] == 300
    assert result["median_ns"] == 200
    assert result["mean_ns"] == 200
    assert result["stddev_ns"] > 0
