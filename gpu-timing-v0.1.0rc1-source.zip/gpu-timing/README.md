# gpu-timing

Lightweight, backend-aware GPU timing and benchmarking for Python.

`gpu-timing` provides a small API for measuring host elapsed time and GPU-event elapsed time while keeping asynchronous execution, warm-up, repetition, and result quality explicit.

## Why

GPU launches are commonly asynchronous from the CPU. A CPU stopwatch can therefore measure only enqueue/launch latency instead of the GPU work you intended to benchmark. `gpu-timing` uses native CUDA/HIP events for GPU timing and reserves host timers for host or end-to-end measurements.

## Installation

```bash
pip install gpu-timing
```

The package has no mandatory third-party runtime dependencies. CUDA or HIP/ROCm must already be installed when using the corresponding backend.

## Quickstart

### Host timing

```python
from gpu_timing import Timer

with Timer(mode="host") as timer:
    do_work()

print(timer.elapsed_ms)
```

### GPU benchmark

```python
from gpu_timing import benchmark

result = benchmark(
    my_gpu_work,
    warmup=10,
    iterations=50,
    mode="gpu",
)

print(result)
```

For explicit backend selection:

```python
result = benchmark(my_gpu_work, backend="cuda")
```

or:

```python
result = benchmark(my_gpu_work, backend="hip")
```

## Measurement semantics

`gpu-timing` distinguishes three modes:

- `host`: Python `perf_counter_ns()` elapsed time.
- `gpu`: elapsed time reported by paired CUDA/HIP events.
- `sync_host`: host elapsed time including an explicit device synchronization.

GPU event elapsed time is not automatically equivalent to pure kernel silicon execution time, application latency, or CPU elapsed time. Stream concurrency and unrelated work can influence an event interval.

## Current scope

The initial release intentionally focuses on correct, lightweight timing. CUPTI, Nsight integration, automatic clock control, cache flushing, distributed benchmarking, and CUDA Graph-specific optimization are outside the v0.1 scope.

## Release status

Current status: **v0.1.0rc1 release candidate**. CPU/static/package validation passes; representative NVIDIA CUDA and AMD ROCm/HIP hardware validation is still required before the final `v0.1.0` release. See `VALIDATION.md` and `docs/hardware-validation.md`.

## Documentation

The project documentation is built with Material for MkDocs and covers installation, methodology, synchronization, streams, warm-up, measurement overhead, backend behavior, troubleshooting, and API details.

## License

MIT. Vendor CUDA and ROCm/HIP runtimes remain external prerequisites and are not bundled by this project.
