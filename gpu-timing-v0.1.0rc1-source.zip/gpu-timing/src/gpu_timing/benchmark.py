"""Repeated benchmark execution."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from .result import BenchmarkResult, default_metadata
from .quality import assess
from .statistics import summarize
from .timer import Timer


def benchmark(
    fn: Callable[[], Any],
    *,
    warmup: int = 10,
    iterations: int = 50,
    mode: str = "gpu",
    backend: str = "auto",
    device: int | None = None,
    stream: Any = None,
    metadata: dict[str, Any] | None = None,
) -> BenchmarkResult:
    """Benchmark a callable repeatedly and return a structured result.

    Warm-up calls are intentionally not timed. Measured samples are executed
    sequentially. GPU samples use paired events and synchronize the end event
    before consuming the elapsed timestamp.
    """
    if warmup < 0:
        raise ValueError("warmup must be >= 0")
    if iterations <= 0:
        raise ValueError("iterations must be > 0")

    timer = Timer(mode=mode, backend=backend, device=device, stream=stream)
    normalized_mode = timer.mode

    for _ in range(warmup):
        fn()

    samples_ns: list[int] = []
    try:
        for _ in range(iterations):
            timer.start()
            try:
                fn()
            except BaseException:
                # Do not let a timing cleanup failure mask the workload's
                # original exception.
                try:
                    timer.stop()
                except Exception:
                    pass
                raise
            timer.stop()
            samples_ns.append(timer.elapsed_ns)
    finally:
        timer.close()

    stats = summarize(samples_ns)
    quality = assess(
        sample_count=int(stats["count"]),
        cv=float(stats["cv"]),
        warmup=warmup,
        mode=normalized_mode,
    )
    result_metadata = default_metadata()
    result_metadata.update(metadata or {})
    result_metadata.update({"backend": timer.backend, "device": timer.device})

    return BenchmarkResult(
        backend=timer.backend,
        device=timer.device,
        mode=normalized_mode,
        warmup=warmup,
        samples=iterations,
        min_ns=int(stats["min_ns"]),
        max_ns=int(stats["max_ns"]),
        mean_ns=float(stats["mean_ns"]),
        median_ns=float(stats["median_ns"]),
        stddev_ns=float(stats["stddev_ns"]),
        cv=float(stats["cv"]),
        quality=quality.status,
        warnings=quality.warnings,
        metadata=result_metadata,
        sample_ns=tuple(samples_ns),
    )
