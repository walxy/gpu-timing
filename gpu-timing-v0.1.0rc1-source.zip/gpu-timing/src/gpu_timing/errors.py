"""Public exceptions raised by gpu-timing."""


class GpuTimingError(RuntimeError):
    """Base exception for gpu-timing failures."""


class BackendUnavailableError(GpuTimingError):
    """Raised when a requested accelerator backend cannot be loaded."""


class BackendError(GpuTimingError):
    """Raised when a native backend API call fails."""


class DeviceError(GpuTimingError):
    """Raised for invalid or incompatible device selection."""


class StreamError(GpuTimingError):
    """Raised for an invalid stream handle or stream configuration."""


class TimingError(GpuTimingError):
    """Raised when a timer cannot complete a valid measurement."""


class ConfigurationError(GpuTimingError):
    """Raised for invalid timer or benchmark configuration."""


class BenchmarkError(GpuTimingError):
    """Raised for invalid or failed benchmark execution."""
