"""Heuristic benchmark-quality assessment."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Quality:
    """Quality state and non-fatal measurement warnings."""

    status: str
    warnings: tuple[str, ...]


def assess(*, sample_count: int, cv: float, warmup: int, mode: str) -> Quality:
    warnings: list[str] = []
    if sample_count < 5:
        warnings.append("fewer than 5 measured samples")
    if warmup == 0 and mode == "gpu":
        warnings.append("GPU warm-up is disabled; initialization/lazy-loading effects may remain")
    if mode == "sync_host":
        warnings.append("sync_host includes an explicit device synchronization and may perturb concurrency")
    if cv != float("inf") and cv > 0.05:
        warnings.append("coefficient of variation exceeds 5%; repeatability may be limited")
    elif cv == float("inf"):
        warnings.append("mean measured duration is zero")

    return Quality(status="good" if not warnings else "warn", warnings=tuple(warnings))
