"""Internal backend protocol and backend discovery."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

from .errors import BackendUnavailableError, ConfigurationError


@dataclass(frozen=True, slots=True)
class BackendInfo:
    """Description of a loaded timing backend."""

    name: str
    device: int


class EventBackend(Protocol):
    """Minimal interface required by the timer."""

    info: BackendInfo

    def start_event(self) -> Any:
        """Create a reusable native timing event."""

    def destroy_event(self, event: Any) -> None:
        """Destroy a native timing event."""

    def record(self, event: Any, stream: Any) -> None:
        """Record an event into a native stream."""

    def synchronize_event(self, event: Any) -> None:
        """Wait until an event has completed."""

    def elapsed_ms(self, start: Any, end: Any) -> float:
        """Return backend-reported elapsed milliseconds."""

    def synchronize_device(self) -> None:
        """Wait for all work on the selected device."""

    def current_device(self) -> int:
        """Return the backend runtime's current device."""

    def ensure_selected_device(self) -> None:
        """Raise if the calling thread changed away from the selected device."""

    def restore_previous_device(self) -> None:
        """Restore the device that was current before backend construction."""


def load_backend(name: str, device: int | None = None) -> EventBackend:
    """Load a CUDA or HIP backend.

    ``name`` may be ``cuda``, ``hip`` or ``auto``. ``auto`` prefers CUDA and
    falls back to HIP when the corresponding native runtime can be loaded.
    """
    normalized = name.lower().strip()
    if normalized not in {"auto", "cuda", "hip"}:
        raise ConfigurationError("backend must be 'auto', 'cuda', or 'hip'")

    if normalized in {"auto", "cuda"}:
        from .backends.cuda import CudaBackend

        try:
            return CudaBackend(device=device)
        except BackendUnavailableError:
            if normalized == "cuda":
                raise

    if normalized in {"auto", "hip"}:
        from .backends.hip import HipBackend

        try:
            return HipBackend(device=device)
        except BackendUnavailableError:
            if normalized == "hip":
                raise

    raise BackendUnavailableError(
        "No supported GPU runtime could be loaded. Install a compatible CUDA or HIP/ROCm runtime."
    )
