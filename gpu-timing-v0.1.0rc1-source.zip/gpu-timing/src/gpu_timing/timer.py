"""Public host and GPU timer implementations."""

from __future__ import annotations

import time
from typing import Any

from .backend import EventBackend, load_backend
from .errors import ConfigurationError, TimingError


class Timer:
    """Reusable timer supporting host, GPU-event, and synchronized-host modes.

    Parameters
    ----------
    mode:
        ``host`` for Python ``perf_counter_ns`` timing, ``gpu`` for CUDA/HIP
        event timing, or ``sync_host`` for host timing with a device
        synchronization after the measured callable/work.
    backend:
        ``auto``, ``cuda`` or ``hip`` for GPU-aware modes.
    device:
        Optional native device index. Explicit selection changes the active
        device for the current host thread/process according to the backend
        runtime's semantics.
    stream:
        Optional native stream handle as an integer or ``ctypes.c_void_p``.
    """

    def __init__(
        self,
        *,
        mode: str = "host",
        backend: str = "auto",
        device: int | None = None,
        stream: Any = None,
    ) -> None:
        self.mode = mode.lower().strip()
        if self.mode not in {"host", "gpu", "sync_host"}:
            raise ConfigurationError("mode must be 'host', 'gpu', or 'sync_host'")
        self._backend: EventBackend | None = None
        self._stream = stream
        self._start_ns: int | None = None
        self._elapsed_ns: int | None = None
        self._started = False
        self._stopped = False
        self._start_event: Any = None
        self._end_event: Any = None

        if self.mode in {"gpu", "sync_host"}:
            self._backend = load_backend(backend, device=device)
        if self.mode == "gpu":
            assert self._backend is not None
            try:
                self._start_event = self._backend.start_event()
                self._end_event = self._backend.start_event()
            except Exception:
                if self._start_event:
                    try:
                        self._backend.destroy_event(self._start_event)
                    except Exception:
                        pass
                    self._start_event = None
                try:
                    self._backend.restore_previous_device()
                except Exception:
                    pass
                raise

    @property
    def backend(self) -> str:
        return self._backend.info.name if self._backend is not None else "host"

    @property
    def device(self) -> int | None:
        return self._backend.info.device if self._backend is not None else None

    @property
    def elapsed_ns(self) -> int:
        if self._elapsed_ns is None:
            raise TimingError("timer has not completed a measurement")
        return self._elapsed_ns

    @property
    def elapsed_ms(self) -> float:
        return self.elapsed_ns / 1_000_000.0

    def start(self) -> "Timer":
        if self._started and not self._stopped:
            raise TimingError("timer is already running")
        self._started = True
        self._stopped = False
        self._elapsed_ns = None
        if self.mode == "host":
            self._start_ns = time.perf_counter_ns()
        elif self.mode == "sync_host":
            self._start_ns = time.perf_counter_ns()
        else:
            assert self._backend is not None
            self._backend.record(self._start_event, self._stream)
        return self

    def stop(self) -> "Timer":
        if not self._started or self._stopped:
            raise TimingError("timer is not running")
        try:
            if self.mode == "host":
                assert self._start_ns is not None
                self._elapsed_ns = time.perf_counter_ns() - self._start_ns
            elif self.mode == "sync_host":
                assert self._backend is not None and self._start_ns is not None
                self._backend.synchronize_device()
                self._elapsed_ns = time.perf_counter_ns() - self._start_ns
            else:
                assert self._backend is not None
                self._backend.record(self._end_event, self._stream)
                self._backend.synchronize_event(self._end_event)
                elapsed_ms = self._backend.elapsed_ms(self._start_event, self._end_event)
                self._elapsed_ns = max(0, round(elapsed_ms * 1_000_000))
        except Exception as exc:
            raise TimingError(f"failed to stop {self.mode} timer") from exc
        finally:
            self._stopped = True
        return self

    def close(self) -> None:
        if self._backend is not None and self.mode == "gpu":
            errors = []
            for event_name in ("_start_event", "_end_event"):
                event = getattr(self, event_name)
                if event:
                    try:
                        self._backend.destroy_event(event)
                    except Exception as exc:
                        errors.append(exc)
                    setattr(self, event_name, None)
            try:
                self._backend.restore_previous_device()
            except Exception as exc:
                errors.append(exc)
            if errors:
                raise TimingError("failed to finalize one or more GPU timing resources") from errors[0]

    def __enter__(self) -> "Timer":
        return self.start()

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        try:
            if exc_type is None:
                self.stop()
            else:
                # Never replace the user's workload exception with a timing
                # failure. The measurement is best-effort when the workload
                # itself raises.
                try:
                    self.stop()
                except Exception:
                    pass
        finally:
            try:
                self.close()
            except Exception:
                if exc_type is None:
                    raise

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass


GPUTimer = Timer
