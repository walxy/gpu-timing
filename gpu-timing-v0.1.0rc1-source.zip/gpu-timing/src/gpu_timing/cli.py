"""Small command-line interface."""

from __future__ import annotations

import argparse
import json


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="gpu-timing")
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("version", help="show the installed gpu-timing version")
    subparsers.add_parser("info", help="show CLI/runtime guidance")
    args = parser.parse_args(argv)

    if args.command == "version":
        from . import __version__

        print(__version__)
        return 0
    if args.command == "info":
        from . import __version__

        print(json.dumps({"gpu_timing": __version__, "runtime_dependencies": []}, indent=2))
        return 0

    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
