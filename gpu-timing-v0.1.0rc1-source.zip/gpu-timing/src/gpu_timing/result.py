"""Benchmark result model and serialization."""

from __future__ import annotations

import json
import platform
import sys
from dataclasses import dataclass
from typing import Any


def _format_ns(value: float) -> str:
    if value < 1_000:
        return f"{value:.1f} ns"
    if value < 1_000_000:
        return f"{value / 1_000:.2f} µs"
    if value < 1_000_000_000:
        return f"{value / 1_000_000:.2f} ms"
    return f"{value / 1_000_000_000:.3f} s"


@dataclass(frozen=True, slots=True)
class BenchmarkResult:
    """Immutable benchmark result."""

    backend: str
    device: int | None
    mode: str
    warmup: int
    samples: int
    min_ns: int
    max_ns: int
    mean_ns: float
    median_ns: float
    stddev_ns: float
    cv: float
    quality: str
    warnings: tuple[str, ...]
    metadata: dict[str, Any]
    sample_ns: tuple[int, ...] = ()

    @property
    def mean_ms(self) -> float:
        return self.mean_ns / 1_000_000.0

    @property
    def median_ms(self) -> float:
        return self.median_ns / 1_000_000.0

    @property
    def min_ms(self) -> float:
        return self.min_ns / 1_000_000.0

    @property
    def max_ms(self) -> float:
        return self.max_ns / 1_000_000.0

    def to_dict(self, *, include_samples: bool = False) -> dict[str, Any]:
        value = {
            "backend": self.backend,
            "device": self.device,
            "mode": self.mode,
            "warmup": self.warmup,
            "samples": self.samples,
            "min_ns": self.min_ns,
            "max_ns": self.max_ns,
            "mean_ns": self.mean_ns,
            "median_ns": self.median_ns,
            "stddev_ns": self.stddev_ns,
            "cv": self.cv,
            "quality": self.quality,
            "warnings": list(self.warnings),
            "metadata": self.metadata,
        }
        if include_samples:
            value["sample_ns"] = list(self.sample_ns)
        return value

    def to_json(self, *, include_samples: bool = False, indent: int = 2) -> str:
        return json.dumps(self.to_dict(include_samples=include_samples), indent=indent, sort_keys=True)

    def __str__(self) -> str:
        lines = [
            "gpu-timing benchmark",
            "--------------------",
            f"backend:   {self.backend}",
            f"device:    {self.device if self.device is not None else 'host'}",
            f"mode:      {self.mode}",
            f"warmup:    {self.warmup}",
            f"samples:   {self.samples}",
            "",
            f"median:    {_format_ns(self.median_ns)}",
            f"mean:      {_format_ns(self.mean_ns)}",
            f"min:       {_format_ns(self.min_ns)}",
            f"max:       {_format_ns(self.max_ns)}",
            f"stddev:    {_format_ns(self.stddev_ns)}",
            f"CV:        {self.cv * 100:.2f}%",
            "",
            f"quality:   {self.quality.upper()}",
        ]
        if self.warnings:
            lines.append("")
            lines.append("warnings:")
            lines.extend(f"- {warning}" for warning in self.warnings)
        return "\n".join(lines)


def default_metadata() -> dict[str, Any]:
    return {
        "python": platform.python_version(),
        "implementation": sys.implementation.name,
        "platform": platform.platform(),
        "machine": platform.machine(),
    }
