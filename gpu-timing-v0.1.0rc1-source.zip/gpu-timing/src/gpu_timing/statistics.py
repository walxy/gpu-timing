"""Small dependency-free benchmark statistics helpers."""

from __future__ import annotations

import math
import statistics
from collections.abc import Iterable

from .errors import BenchmarkError


def summarize(values_ns: Iterable[int]) -> dict[str, float | int]:
    """Return summary statistics for positive integer nanosecond samples."""
    values = tuple(int(v) for v in values_ns)
    if not values:
        raise BenchmarkError("at least one measurement sample is required")
    if any(v < 0 for v in values):
        raise BenchmarkError("measurement samples cannot be negative")

    mean = statistics.fmean(values)
    stdev = statistics.stdev(values) if len(values) >= 2 else 0.0
    median = statistics.median(values)
    cv = stdev / mean if mean > 0 else math.inf
    return {
        "count": len(values),
        "min_ns": min(values),
        "max_ns": max(values),
        "mean_ns": mean,
        "median_ns": median,
        "stddev_ns": stdev,
        "cv": cv,
    }
