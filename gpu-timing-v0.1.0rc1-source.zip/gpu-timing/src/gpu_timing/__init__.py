"""Lightweight, backend-aware GPU timing and benchmarking for Python."""

from .benchmark import benchmark
from .errors import (
    BackendError,
    BackendUnavailableError,
    BenchmarkError,
    ConfigurationError,
    DeviceError,
    GpuTimingError,
    StreamError,
    TimingError,
)
from .result import BenchmarkResult
from .timer import GPUTimer, Timer

__version__ = "0.1.0rc1"

__all__ = [
    "BackendError",
    "BackendUnavailableError",
    "BenchmarkError",
    "BenchmarkResult",
    "ConfigurationError",
    "DeviceError",
    "GPUTimer",
    "GpuTimingError",
    "StreamError",
    "Timer",
    "TimingError",
    "benchmark",
]
