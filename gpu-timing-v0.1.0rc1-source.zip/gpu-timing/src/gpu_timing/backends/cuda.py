"""Minimal CUDA Runtime API bindings used by gpu-timing."""

from __future__ import annotations

import ctypes
import ctypes.util
import os
from typing import Any

from ..backend import BackendInfo
from ..errors import BackendError, BackendUnavailableError, DeviceError, StreamError


_CudaEvent = ctypes.c_void_p


class CudaBackend:
    """Small ctypes wrapper around CUDA event timing primitives."""

    _UNAVAILABLE_ERRORS = {3, 35, 100, 802, 803, 804}

    def __init__(self, device: int | None = None) -> None:
        self._lib = self._load_library()
        self._configure()
        self._previous_device = self._current_device_or_unavailable()
        count = ctypes.c_int()
        code = self._lib.cudaGetDeviceCount(ctypes.byref(count))
        if code != 0:
            self._raise_availability_status(code, "cudaGetDeviceCount")
        if count.value <= 0:
            raise BackendUnavailableError("CUDA runtime reports no CUDA-capable devices")
        selected = self._previous_device
        if device is not None:
            if device < 0 or device >= count.value:
                raise DeviceError(f"CUDA device index {device} is out of range (count={count.value})")
            self._check_status(self._lib.cudaSetDevice(device), "cudaSetDevice")
            selected = device
        self.info = BackendInfo(name="cuda", device=selected)

    @staticmethod
    def _load_library() -> ctypes.CDLL:
        candidates = []
        env = os.environ.get("GPU_TIMING_CUDA_LIBRARY")
        if env:
            candidates.append(env)
        discovered = ctypes.util.find_library("cudart")
        if discovered:
            candidates.append(discovered)
        candidates.extend(
            [
                "libcudart.so",
                "libcudart.so.13",
                "libcudart.so.12",
                "cudart.dll",
                "cudart64_13.dll",
                "cudart64_12.dll",
                "cudart64_11.dll",
            ]
        )
        seen: set[str] = set()
        for candidate in candidates:
            if not candidate or candidate in seen:
                continue
            seen.add(candidate)
            try:
                return ctypes.CDLL(candidate)
            except OSError:
                continue
        raise BackendUnavailableError(
            "CUDA runtime library (cudart) could not be loaded. "
            "Set GPU_TIMING_CUDA_LIBRARY to an explicit library path if needed."
        )

    def _configure(self) -> None:
        lib = self._lib
        lib.cudaGetDevice.argtypes = [ctypes.POINTER(ctypes.c_int)]
        lib.cudaGetDevice.restype = ctypes.c_int
        lib.cudaGetDeviceCount.argtypes = [ctypes.POINTER(ctypes.c_int)]
        lib.cudaGetDeviceCount.restype = ctypes.c_int
        lib.cudaSetDevice.argtypes = [ctypes.c_int]
        lib.cudaSetDevice.restype = ctypes.c_int
        lib.cudaEventCreate.argtypes = [ctypes.POINTER(_CudaEvent)]
        lib.cudaEventCreate.restype = ctypes.c_int
        lib.cudaEventRecord.argtypes = [_CudaEvent, ctypes.c_void_p]
        lib.cudaEventRecord.restype = ctypes.c_int
        lib.cudaEventSynchronize.argtypes = [_CudaEvent]
        lib.cudaEventSynchronize.restype = ctypes.c_int
        lib.cudaEventElapsedTime.argtypes = [ctypes.POINTER(ctypes.c_float), _CudaEvent, _CudaEvent]
        lib.cudaEventElapsedTime.restype = ctypes.c_int
        lib.cudaEventDestroy.argtypes = [_CudaEvent]
        lib.cudaEventDestroy.restype = ctypes.c_int
        lib.cudaDeviceSynchronize.argtypes = []
        lib.cudaDeviceSynchronize.restype = ctypes.c_int
        if hasattr(lib, "cudaGetErrorString"):
            lib.cudaGetErrorString.argtypes = [ctypes.c_int]
            lib.cudaGetErrorString.restype = ctypes.c_char_p

    def _current_device_or_unavailable(self) -> int:
        value = ctypes.c_int()
        code = self._lib.cudaGetDevice(ctypes.byref(value))
        if code != 0:
            self._raise_availability_status(code, "cudaGetDevice")
        return value.value

    def _current_device(self) -> int:
        value = ctypes.c_int()
        self._check_status(self._lib.cudaGetDevice(ctypes.byref(value)), "cudaGetDevice")
        return value.value

    def _raise_availability_status(self, code: int, operation: str) -> None:
        if code in self._UNAVAILABLE_ERRORS:
            description = self._error_description(code)
            suffix = f": {description}" if description else ""
            raise BackendUnavailableError(
                f"CUDA {operation} cannot use the CUDA runtime/device (error {code}{suffix})"
            )
        self._check_status(code, operation)

    def _error_description(self, code: int) -> str | None:
        if not hasattr(self._lib, "cudaGetErrorString"):
            return None
        raw = self._lib.cudaGetErrorString(code)
        return raw.decode("utf-8", errors="replace") if raw else None

    def _check_status(self, code: int, operation: str) -> None:
        if code == 0:
            return
        description = self._error_description(code)
        suffix = f": {description}" if description else ""
        raise BackendError(f"CUDA {operation} failed with error {code}{suffix}")

    @staticmethod
    def _stream_handle(stream: Any) -> ctypes.c_void_p:
        if stream is None:
            return ctypes.c_void_p()
        if isinstance(stream, ctypes.c_void_p):
            return stream
        if isinstance(stream, int):
            if stream < 0:
                raise StreamError("stream handle must be non-negative")
            return ctypes.c_void_p(stream)
        raise StreamError("stream must be None, an integer native handle, or ctypes.c_void_p")

    def start_event(self) -> _CudaEvent:
        event = _CudaEvent()
        self._check_status(self._lib.cudaEventCreate(ctypes.byref(event)), "cudaEventCreate")
        return event

    def destroy_event(self, event: _CudaEvent) -> None:
        if not event:
            return
        current = self._current_device()
        switched = current != self.info.device
        if switched:
            self._check_status(self._lib.cudaSetDevice(self.info.device), "cudaSetDevice")
        try:
            self._check_status(self._lib.cudaEventDestroy(event), "cudaEventDestroy")
        finally:
            if switched:
                self._check_status(self._lib.cudaSetDevice(current), "cudaSetDevice")

    def record(self, event: _CudaEvent, stream: Any) -> None:
        self.ensure_selected_device()
        self._check_status(self._lib.cudaEventRecord(event, self._stream_handle(stream)), "cudaEventRecord")

    def synchronize_event(self, event: _CudaEvent) -> None:
        self.ensure_selected_device()
        self._check_status(self._lib.cudaEventSynchronize(event), "cudaEventSynchronize")

    def elapsed_ms(self, start: _CudaEvent, end: _CudaEvent) -> float:
        self.ensure_selected_device()
        value = ctypes.c_float()
        self._check_status(
            self._lib.cudaEventElapsedTime(ctypes.byref(value), start, end),
            "cudaEventElapsedTime",
        )
        return float(value.value)

    def synchronize_device(self) -> None:
        self.ensure_selected_device()
        self._check_status(self._lib.cudaDeviceSynchronize(), "cudaDeviceSynchronize")

    def current_device(self) -> int:
        return self._current_device()

    def ensure_selected_device(self) -> None:
        current = self._current_device()
        if current != self.info.device:
            raise DeviceError(
                f"CUDA current device changed from {self.info.device} to {current} during timing"
            )

    def restore_previous_device(self) -> None:
        current = self._current_device()
        if current != self._previous_device:
            self._check_status(self._lib.cudaSetDevice(self._previous_device), "cudaSetDevice")
