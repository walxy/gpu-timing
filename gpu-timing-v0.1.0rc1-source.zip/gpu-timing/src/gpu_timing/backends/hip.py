"""Minimal HIP Runtime API bindings used by gpu-timing."""

from __future__ import annotations

import ctypes
import ctypes.util
import os
from typing import Any

from ..backend import BackendInfo
from ..errors import BackendError, BackendUnavailableError, DeviceError, StreamError


_HipEvent = ctypes.c_void_p


class HipBackend:
    """Small ctypes wrapper around HIP event timing primitives."""

    _UNAVAILABLE_ERRORS = {100}

    def __init__(self, device: int | None = None) -> None:
        self._lib = self._load_library()
        self._configure()
        self._previous_device = self._current_device_or_unavailable()
        count = ctypes.c_int()
        code = self._lib.hipGetDeviceCount(ctypes.byref(count))
        if code != 0:
            self._raise_availability_status(code, "hipGetDeviceCount")
        if count.value <= 0:
            raise BackendUnavailableError("HIP runtime reports no compute-capable devices")
        selected = self._previous_device
        if device is not None:
            if device < 0 or device >= count.value:
                raise DeviceError(f"HIP device index {device} is out of range (count={count.value})")
            self._check_status(self._lib.hipSetDevice(device), "hipSetDevice")
            selected = device
        self.info = BackendInfo(name="hip", device=selected)

    @staticmethod
    def _load_library() -> ctypes.CDLL:
        candidates = []
        env = os.environ.get("GPU_TIMING_HIP_LIBRARY")
        if env:
            candidates.append(env)
        discovered = ctypes.util.find_library("amdhip64")
        if discovered:
            candidates.append(discovered)
        candidates.extend(["libamdhip64.so", "amdhip64.dll"])
        seen: set[str] = set()
        for candidate in candidates:
            if not candidate or candidate in seen:
                continue
            seen.add(candidate)
            try:
                return ctypes.CDLL(candidate)
            except OSError:
                continue
        raise BackendUnavailableError(
            "HIP runtime library (amdhip64) could not be loaded. "
            "Set GPU_TIMING_HIP_LIBRARY to an explicit library path if needed."
        )

    def _configure(self) -> None:
        lib = self._lib
        lib.hipGetDevice.argtypes = [ctypes.POINTER(ctypes.c_int)]
        lib.hipGetDevice.restype = ctypes.c_int
        lib.hipGetDeviceCount.argtypes = [ctypes.POINTER(ctypes.c_int)]
        lib.hipGetDeviceCount.restype = ctypes.c_int
        lib.hipSetDevice.argtypes = [ctypes.c_int]
        lib.hipSetDevice.restype = ctypes.c_int
        lib.hipEventCreate.argtypes = [ctypes.POINTER(_HipEvent)]
        lib.hipEventCreate.restype = ctypes.c_int
        lib.hipEventRecord.argtypes = [_HipEvent, ctypes.c_void_p]
        lib.hipEventRecord.restype = ctypes.c_int
        lib.hipEventSynchronize.argtypes = [_HipEvent]
        lib.hipEventSynchronize.restype = ctypes.c_int
        lib.hipEventElapsedTime.argtypes = [ctypes.POINTER(ctypes.c_float), _HipEvent, _HipEvent]
        lib.hipEventElapsedTime.restype = ctypes.c_int
        lib.hipEventDestroy.argtypes = [_HipEvent]
        lib.hipEventDestroy.restype = ctypes.c_int
        lib.hipDeviceSynchronize.argtypes = []
        lib.hipDeviceSynchronize.restype = ctypes.c_int
        if hasattr(lib, "hipGetErrorString"):
            lib.hipGetErrorString.argtypes = [ctypes.c_int]
            lib.hipGetErrorString.restype = ctypes.c_char_p

    def _current_device_or_unavailable(self) -> int:
        value = ctypes.c_int()
        code = self._lib.hipGetDevice(ctypes.byref(value))
        if code != 0:
            self._raise_availability_status(code, "hipGetDevice")
        return value.value

    def _current_device(self) -> int:
        value = ctypes.c_int()
        self._check_status(self._lib.hipGetDevice(ctypes.byref(value)), "hipGetDevice")
        return value.value

    def _raise_availability_status(self, code: int, operation: str) -> None:
        if code in self._UNAVAILABLE_ERRORS:
            description = self._error_description(code)
            suffix = f": {description}" if description else ""
            raise BackendUnavailableError(
                f"HIP {operation} cannot use the HIP runtime/device (error {code}{suffix})"
            )
        self._check_status(code, operation)

    def _error_description(self, code: int) -> str | None:
        if not hasattr(self._lib, "hipGetErrorString"):
            return None
        raw = self._lib.hipGetErrorString(code)
        return raw.decode("utf-8", errors="replace") if raw else None

    def _check_status(self, code: int, operation: str) -> None:
        if code == 0:
            return
        description = self._error_description(code)
        suffix = f": {description}" if description else ""
        raise BackendError(f"HIP {operation} failed with error {code}{suffix}")

    @staticmethod
    def _stream_handle(stream: Any) -> ctypes.c_void_p:
        if stream is None:
            return ctypes.c_void_p()
        if isinstance(stream, ctypes.c_void_p):
            return stream
        if isinstance(stream, int):
            if stream < 0:
                raise StreamError("stream handle must be non-negative")
            return ctypes.c_void_p(stream)
        raise StreamError("stream must be None, an integer native handle, or ctypes.c_void_p")

    def start_event(self) -> _HipEvent:
        event = _HipEvent()
        self._check_status(self._lib.hipEventCreate(ctypes.byref(event)), "hipEventCreate")
        return event

    def destroy_event(self, event: _HipEvent) -> None:
        if not event:
            return
        current = self._current_device()
        switched = current != self.info.device
        if switched:
            self._check_status(self._lib.hipSetDevice(self.info.device), "hipSetDevice")
        try:
            self._check_status(self._lib.hipEventDestroy(event), "hipEventDestroy")
        finally:
            if switched:
                self._check_status(self._lib.hipSetDevice(current), "hipSetDevice")

    def record(self, event: _HipEvent, stream: Any) -> None:
        self.ensure_selected_device()
        self._check_status(self._lib.hipEventRecord(event, self._stream_handle(stream)), "hipEventRecord")

    def synchronize_event(self, event: _HipEvent) -> None:
        self.ensure_selected_device()
        self._check_status(self._lib.hipEventSynchronize(event), "hipEventSynchronize")

    def elapsed_ms(self, start: _HipEvent, end: _HipEvent) -> float:
        self.ensure_selected_device()
        value = ctypes.c_float()
        self._check_status(
            self._lib.hipEventElapsedTime(ctypes.byref(value), start, end),
            "hipEventElapsedTime",
        )
        return float(value.value)

    def synchronize_device(self) -> None:
        self.ensure_selected_device()
        self._check_status(self._lib.hipDeviceSynchronize(), "hipDeviceSynchronize")

    def current_device(self) -> int:
        return self._current_device()

    def ensure_selected_device(self) -> None:
        current = self._current_device()
        if current != self.info.device:
            raise DeviceError(
                f"HIP current device changed from {self.info.device} to {current} during timing"
            )

    def restore_previous_device(self) -> None:
        current = self._current_device()
        if current != self._previous_device:
            self._check_status(self._lib.hipSetDevice(self._previous_device), "hipSetDevice")
