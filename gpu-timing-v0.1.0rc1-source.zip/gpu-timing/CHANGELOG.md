# Changelog

## 0.1.0rc1 — Initial release candidate

### Added

- Host timing with `time.perf_counter_ns()`.
- CUDA timing through native CUDA Runtime API events via `ctypes`.
- HIP timing through native HIP events via `ctypes`.
- Reusable `Timer` / `GPUTimer` API.
- Dependency-free benchmark statistics.
- Warm-up and repeated benchmark execution.
- Structured `BenchmarkResult` with JSON serialization.
- Basic benchmark-quality warnings.
- Initial CLI.
- Material for MkDocs documentation.
- Explicit validation status and hardware-validation gate.

### Validation

- CPU-only unit tests: **13 passed** in the current validation environment.
- Python source compilation/import and CLI smoke tests: **PASS**.
- Wheel build and isolated installation: **PASS**.
- NVIDIA CUDA hardware validation: **PENDING**.
- AMD ROCm/HIP hardware validation: **PENDING**.
- GPU timing-overhead characterization: **PENDING HARDWARE**.

### Known limitations

- CUDA/HIP hardware execution has not yet been validated on representative accelerator systems in this validation cycle.
- CUDA/HIP event elapsed time must not be interpreted as an isolated kernel-execution measurement under arbitrary multi-stream concurrency.
- GPU clocks, thermals, initialization, scheduling, and system load can affect benchmark results.
- CUDA/HIP runtime libraries are external prerequisites and are not bundled.
- Stream parameters require native integer/`ctypes.c_void_p` handles.
- CUPTI, Nsight, CUDA Graph-specific optimization, clock control, cache control, distributed benchmarking, and automatic calibration are outside the v0.1 scope.
