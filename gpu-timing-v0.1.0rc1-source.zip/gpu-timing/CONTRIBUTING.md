# Contributing

Keep the project small and evidence-driven.

## Development

```bash
python -m pip install -e '.[dev]'
pytest
ruff check .
ruff format --check .
mkdocs build --strict
```

## Engineering priorities

1. Correctness of timing semantics.
2. Explicit CUDA/HIP stream and device behavior.
3. Stable public API.
4. Measurement quality and reproducibility.
5. Low measurement overhead.
6. Convenience features.

Changes that add a dependency or abstraction should have a clear user or correctness benefit.
